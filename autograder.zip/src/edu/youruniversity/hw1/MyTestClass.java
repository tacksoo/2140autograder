package edu.youruniversity.hw1;

import org.junit.Test;
import static org.junit.Assert.*;
// This is an annotation for assigning point values to tests
import com.gradescope.jh61b.grader.GradedTest;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

// Import anything else you need to run the tests, such as the students' classes

public class MyTestClass {
    @Test
    @GradedTest(name="Test 1+1", max_score=1)
    public void test_1p1() {
        int x = 1 + 1;
        System.out.println("Tested 1+1, got " + x);
        assertEquals(x, 2);
    }

    @Test
    @GradedTest(name="Test 1+1*2", max_score=1, visibility="after_published")
    public void test_1p1t2() {
        int x = 1 + 1 * 2;
        System.out.println("Tested 1+1*2, got " + x);
        assertEquals(x, 3);
    }

    @Test
    @GradedTest(name="Test FtoC", max_score=2)
    public void test_ftoc() {

        System.out.println("Testing 32f");
        assertEquals(StudentFile.fToC(32),0,0);

        System.out.println("Testing 212f");
        assertEquals(StudentFile.fToC(212),100.0,0);
    }

    @Test
    @GradedTest(name="Testing Hello World", max_score=1)
    public void test_hello() {
        PrintStream stdOut = System.out;
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        System.setOut(new PrintStream(bos));
        StudentFile.helloWorld();
        assertEquals(bos.toString().trim(),"hello world");
        System.setOut(stdOut);
    }

    @Test
    @GradedTest(name="Testing main method", max_score = 1)
    public void test_main() {
        StudentFile2.main(null);
    }


}
